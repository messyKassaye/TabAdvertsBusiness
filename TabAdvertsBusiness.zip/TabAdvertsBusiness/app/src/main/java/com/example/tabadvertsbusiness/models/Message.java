package com.example.tabadvertsbusiness.models;

public class Message {
    private String message;

    public Message() {
    }

    public String getMessages() {
        return message;
    }

    public void setMessages(String message) {
        this.message = message;
    }
}
