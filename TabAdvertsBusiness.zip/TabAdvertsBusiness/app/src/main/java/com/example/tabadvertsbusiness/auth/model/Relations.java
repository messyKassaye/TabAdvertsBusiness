package com.example.tabadvertsbusiness.auth.model;

import com.example.tabadvertsbusiness.models.Role;

import java.util.List;

public class Relations {
    private List<Role> role;
    private List<Car> cars;
}
