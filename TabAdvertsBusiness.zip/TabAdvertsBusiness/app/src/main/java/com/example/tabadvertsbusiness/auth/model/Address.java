package com.example.tabadvertsbusiness.auth.model;

public class Address {
}
