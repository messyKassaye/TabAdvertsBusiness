package com.example.tabadvertsbusiness.auth.model;

public class Advert {
    private int id;
}
